<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="UTF-8">
	<title>Task 1</title>
	<!-- Latest compiled and minified CSS -->
<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css">

<!-- jQuery library -->
<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.4.0/jquery.min.js"></script>

<!-- Popper JS -->
<script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.7/umd/popper.min.js"></script>

<!-- Latest compiled JavaScript -->
<script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.3.1/js/bootstrap.min.js"></script>
	<style type="text/css">
		form
		{
			width: 50%;
			margin: auto;
			margin-top:100px;
			background: black;
			display: flex;
			flex-direction: column;
			padding: 20px;
			opacity: .8;

		}
		form label
		{
			color: white;
			font-weight: bold;
		}
		form input
		{
			background: transparent;
			border: none;
			outline: none;
			border-bottom: 1px solid white;
			padding: 5px;
			font-size:20px;
			color: white;
			margin-left: 20px;

		}
		input.button
		{
			width: 30%;
			height:50px;
			border-radius: 5px;
			color: white;
			text-transform: uppercase;
			background: #339900;
			margin:auto;
			margin-top: 20px;
			font-size: 20px;
			border: none;
			outline: none;
		}
		input.button:hover
		{
			background: #33CC00;
		}
	</style>


</head>
<body>
	<h1 style="text-align: center;">Task 1</h1>
	@if(count($errors) > 0 )
	<div class="alert alert-danger">

		<ul>
			@foreach($errors->all() as $error)
				<li>{{$error}}</li>
			@endforeach

		</ul>


	</div>
	@if(\Session::has('success'))
	<div class="alert alert-success">
		<p>{{\Session::get('success')}}</p>

	</div>
	@endif
	@endif




	<form action="{{url('insert')}}" method="post">

		<label for="name">Name</label>
			<input type="text" id="uname" name="name"/>
		<label for="email">Email</label>
			<input type="email" id="uemail" name="email"/>
		<label for="pin">Pin</label>
			<input type="number" min="000000" max="999999" id="upin" name="pin" />
		{{csrf_field()}}

		<input type="submit" name="save" class="button" value="submit">
	</form>


</body>
</html>