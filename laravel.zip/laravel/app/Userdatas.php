<?php
namespace App;

use Illuminate\Database\Eloquent\Model;

/**
 *
 */
class Userdatas extends Model {

	protected $filable = ['f_name', 'f_email', 'f_pin'];
}